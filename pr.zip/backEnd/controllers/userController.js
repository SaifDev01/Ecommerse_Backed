const ErrorHandler = require("../utils/errorHandler")
const cathAsyncError = require("../middleWare/asyncErrors")
const User  = require("../models/userModel")

exports.registerUser = cathAsyncError(async(req,res,next)=>{
    const {name , email , password} = req.body
    const user = await User.create({
        name,email,password,
        avatar:{
            public_id :"this is Sample ID",
            url : "This is sample url"
        }
    })
    const token = user.getJWTToken();

    res.status(201).json({
        success : true,
        token
    })
})

exports.loginUser = cathAsyncError(async(req,res,next)=>{
    const {email, password} = req.body
    if(!email ||password){
        return next(new ErrorHandler("Please Enter Username or Password" , 501))
    }
})

