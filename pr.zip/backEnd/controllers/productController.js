const { cwd } = require("process")
const Product = require("../models/productModel");
const ErrorHandler = require("../utils/errorHandler");
const AsyncError = require("../middleWare/asyncErrors");
const ApiFeatures = require("../utils/apiFeatures");
const { query } = require("express");
// Admin
exports.createProduct = AsyncError(async(req , res, next)=>{
    // console.log(req.body);
    const product = await Product.create(req.body);
    res.status(201).json({
        success: true,
        product  
    }) 

})

    


exports.getAllProducts= AsyncError(async(req,res)=>{
    const resultPerPage = 10;
    const productCount = await Product.countDocuments()
    // console.log(req.query)
    const apiFeatures  = new ApiFeatures(Product.find(), req.query).search().filter().pagination(resultPerPage)
    
    const products = await apiFeatures.query
    res.status(200).json({
        success : true,
        products,
        productCount 

})
})
exports.deleteProduct = AsyncError(async(req,res, next)=>{
    console.log("saif");
    const _id = req.params.id
    let product = await Product.findById(_id)
    if(!product){
        return next(new ErrorHandler("Product not Found", 404))
    }
    product = await Product.findByIdAndDelete(_id)
    res.status(200).json({
        success : true,
        product
    })
    
})



exports.updateProduct = AsyncError(async(req, res, next)=>{
    const _id = req.params.id
    let product = await Product.findById(_id)
    if(!product){
        return next(new ErrorHandler("Product not Found", 404))
    }
    
    product = await Product.findByIdAndUpdate(_id,req.body ,{new:true})
    res.status(200).json({
        success:true,
        product
    })

})

exports.getProduct = AsyncError(async(req,res,next)=>{
    const _id = req.params.id
    let product = await Product.findById(_id)
    if(!product){
        return next(new ErrorHandler("Product not Found", 404))
    }
    res.status(200).json({
        success: true,
        product
    })
}
)




