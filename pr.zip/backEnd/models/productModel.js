const mongoose = require("mongoose")

const productSchema = new k
mongoose.Schema({
    name: {
        type : String,
        required : [true,"Please Enter Product Name"],
        trim: true
    },
    description:{
        type:String,
        required: [true , "Please Enter Product Description"]
    },
    price: {
        type: Number,
        required: [true , "Please Enter Product's Price"],
        maxLength: [8 , "Price can not exceed 8 digits"],
    },
    rating:{ 
        type:Number,
        default : 0
    },
    images:[
        {
            public_id:{
                type: String,
                required: true
            },
            url : {
                type: String,
                required: true
            }
        }
    ],

    catagory : {
        type: String,
        required: [true, "Please Enter Product Category"]
    },
    stock :{
        type: Number,
        required : [true , "Please Enter Product Stock"],
        maxLength : [4 , "Stock can not exceed 4 digit"],
        default : 1
    }, 
    numOfReview: {
        type : Number,
        default: 0
    },
    review :[
        {
            name :{
                type : String ,
                required : true
            },
            rating : {
                type : Number,
                required : true
            },
            comment:{
                type: String,
                required : true,

            } 
        }
    ],
    createdAt:{
        type : Date,
        default : Date.now
    }
}) 


module.exports = mongoose.model("Product", productSchema)
